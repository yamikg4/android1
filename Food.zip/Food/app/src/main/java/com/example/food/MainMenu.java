package com.example.food;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.HashMap;
import java.util.Map;

public class MainMenu extends AppCompatActivity {
Button signinemail,siginphone,singup;
ImageView bgimage;
String s1,s2;
FirebaseAuth Fauth;
RadioButton rd1,rd2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        final Animation zoomin = AnimationUtils.loadAnimation(this, R.anim.zoomin);
        final Animation zoomout = AnimationUtils.loadAnimation(this, R.anim.zoomout);

        bgimage = findViewById(R.id.back2);
        bgimage.setAnimation(zoomin);
        bgimage.setAnimation(zoomout);

        zoomout.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                bgimage.startAnimation(zoomin);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        rd1=findViewById(R.id.admin);
        rd2=findViewById(R.id.customer);
        TextInputLayout et1 = (TextInputLayout) findViewById(R.id.Demail);
        TextInputLayout et2 = (TextInputLayout) findViewById(R.id.Dpassword);
        Button Login = (Button) findViewById(R.id.bt1);
        Button SNGUP = (Button) findViewById(R.id.bt2);
        TextView tv=(TextView)findViewById(R.id.Dforgotpass);
        Fauth = FirebaseAuth.getInstance();

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    s1 = et1.getEditText().getText().toString().trim();
                    s2 = et2.getEditText().getText().toString().trim();
                    if (rd1.isChecked()) {
                        if (s1.equals("yamikgandhi@gmail.com") && s2.equals("Yamik1234")) {
                            final ProgressDialog mDialog = new ProgressDialog(MainMenu.this);
                            mDialog.setCanceledOnTouchOutside(true);
                            mDialog.setCancelable(true);
                            mDialog.setMessage("Sign In Please Wait.......");
                            mDialog.dismiss();
                            Toast.makeText(MainMenu.this, "Login Admin Sucessfully", Toast.LENGTH_SHORT).show();
                            Intent admin = new Intent(MainMenu.this, Admin.class);
                            startActivity(admin);

                        } else {
                            if(isValid()){
                                ReusableCodeForAll.ShowAlert(MainMenu.this,"","Invaild Admin");
                            }
                        }
                    } else if (rd2.isChecked()) {
                        if (isValid()) {

                            final ProgressDialog mDialog = new ProgressDialog(MainMenu.this);
                            mDialog.setCanceledOnTouchOutside(false);
                            mDialog.setCancelable(false);
                            mDialog.setMessage("Sign In Please Wait.......");
                            mDialog.show();

                            Fauth.signInWithEmailAndPassword(s1, s2).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    if (task.isSuccessful()) {
                                        mDialog.dismiss();

                                        if (Fauth.getCurrentUser().isEmailVerified()) {
                                            mDialog.dismiss();
                                            Toast.makeText(MainMenu.this, "Congratulation! You Have Successfully Login", Toast.LENGTH_SHORT).show();
                                            Intent Z = new Intent(MainMenu.this, Customer.class);
                                            startActivity(Z);
                                            finish();

                                        } else {
                                            ReusableCodeForAll.ShowAlert(MainMenu.this, "Verification Failed", "You Have Not Verified Your Email");

                                        }
                                    } else {
                                        mDialog.dismiss();
                                        ReusableCodeForAll.ShowAlert(MainMenu.this, "Error", task.getException().getMessage());
                                    }
                                }
                            });
                        }
                    }

                }
            String emailpattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
            public boolean isValid() {

                et1.setErrorEnabled(false);
                et1.setError("");
                et2.setErrorEnabled(false);
                et2.setError("");

                boolean isvalid = false, isvalidemail = false, isvalidpassword = false;
                if (TextUtils.isEmpty(s1)) {
                    et1.setErrorEnabled(true);
                    et1.setError("Email is required");
                } else {
                    if (s1.matches(emailpattern)) {
                        isvalidemail = true;
                    } else {
                        et1.setErrorEnabled(true);
                        et1.setError("Invalid Email Address");
                    }
                }
                if (TextUtils.isEmpty(s2)) {

                    et2.setErrorEnabled(true);
                    et2.setError("Password is Required");
                } else {
                    isvalidpassword = true;
                }
                isvalid = (isvalidemail && isvalidpassword) ? true : false;
                return isvalid;
            }
        });

        SNGUP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainMenu.this, singup.class);
                startActivity(intent);
            }
        });
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainMenu.this,Forgot.class);
                startActivity(i);
            }
        });


    }}
